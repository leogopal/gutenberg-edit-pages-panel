# gutenberg-edit-pages-panel

[Playground](https://playground.wordpress.net/?blueprint-url=https://raw.githubusercontent.com/leogopal/gutenberg-edit-pages-panel/main/_playground/blueprint.json)
